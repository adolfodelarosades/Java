public class Empleado {
	
	private long id;
	private String nombre;
	private String email;
	private String telefono;

    //constructores, getters y setters


}